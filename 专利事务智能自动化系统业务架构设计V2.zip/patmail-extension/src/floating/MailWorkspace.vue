<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import type { CustomerQueryProfile } from '../customer/types'
import { planDrafts, selectionFingerprint, upsertMapping, type MailDraftPreview, type MailRuleBundle, type SelectedPatentFile, MailRuleRepository, emptyMailRules } from '../mail'
import type { MailExecutionState } from '../mail/easy/types'
import AutomationPanel from './AutomationPanel.vue'
import ControlledExecutionPanel from './ControlledExecutionPanel.vue'
import LiveAcceptancePanel from './LiveAcceptancePanel.vue'
import MailExecutionPanel from './MailExecutionPanel.vue'
import WorkflowPanel from './WorkflowPanel.vue'
import { plainClone, queryTemplateVersionOf } from '../automation/snapshot'
import { isConfirmedOperator } from '../automation/operator'
import { ChromeBundleRepository, storageKey } from '../storage/query-bundle'
import { scopeFromConnection } from '../shared/connection'
import { MessageType, type MessageBridge } from '../shared/message'
import { sendToBackground } from '../utils/runtime'
import { useWorkspace } from '../app/composables/useWorkspace'
import ThemeSelect from '../../../src/components/ThemeSelect.vue'
import EmptyGuide from '../app/components/EmptyGuide.vue'

const props = defineProps<{ bridge?: MessageBridge; userId: string; files: SelectedPatentFile[]; pageOrigin?: string }>()
const accountOrigin = computed(() => props.pageOrigin || location.origin)
const customers = ref<CustomerQueryProfile[]>([])
const bundle = ref<MailRuleBundle>(emptyMailRules('session'))
const scope = ref<'account' | 'session'>('session')
const message = ref('')
const mailTypes = ref<Array<{ id: string; name: string }>>([])
const drafts = ref<MailDraftPreview[]>([])
const mailStates = ref<Record<string, { mailId: string; state: MailExecutionState | '' }>>({})
const repository = ref<MailRuleRepository | null>(null)
const policyCustomer = ref('')
const policyMode = ref<'merge_by_customer_description' | 'single_file'>('merge_by_customer_description')
const mapText = ref('')
const mapTypeId = ref('')
const editingMapId = ref('')
const recipientCustomer = ref('')
const recipientTo = ref('')
const recipientCc = ref('')
const signatureName = ref('默认签名')
const signatureContent = ref('')
const subjectTemplate = ref('关于{文件名称}的通知')
const countInjection = ref(false)
const missingAnchor = ref<'keep' | 'prefix' | 'confirm'>('keep')
const bodyTemplate = ref('请查收{文件数量}个文件。')
const bodySupplement = ref('')
const importText = ref('')

const owner = computed(() => props.userId || 'session')
const queryTemplateVersion = computed(() => queryTemplateVersionOf(customers.value))
const scopeLabel = computed(() => scope.value === 'account' ? '当前账号' : '本次页面，未套用其他账号配置')

async function reloadCustomers(): Promise<void> {
  const key = storageKey(accountOrigin.value, props.userId || null)
  if (typeof chrome === 'undefined' || !chrome.storage?.local || !props.userId) {
    customers.value = []
    return
  }
  const loaded = await new ChromeBundleRepository(key).load()
  customers.value = loaded.bundle.customers
}
async function reloadRules(): Promise<void> {
  repository.value = new MailRuleRepository(owner.value, accountOrigin.value, props.userId && typeof chrome !== 'undefined' ? chrome.storage?.local ?? null : null)
  const loaded = await repository.value.load()
  bundle.value = loaded.bundle
  scope.value = loaded.scope
  message.value = loaded.warning ?? ''
  subjectTemplate.value = loaded.bundle.subject.template
  countInjection.value = loaded.bundle.subject.countInjection
  missingAnchor.value = loaded.bundle.subject.missingAnchor
  bodyTemplate.value = loaded.bundle.body.template
  bodySupplement.value = loaded.bundle.body.supplement
  drafts.value = []
}
async function loadMailTypes(): Promise<void> {
  if (!props.bridge) return
  const response = await props.bridge.request({ type: MessageType.LoadDictionary, payload: { kind: 'mailType', force: false } })
  if (response.type !== MessageType.DictionaryResult || !response.payload.ok || response.payload.data.kind !== 'mailType') {
    message.value = response.type === MessageType.DictionaryResult && !response.payload.ok ? response.payload.error.message : '发文类型加载失败，不会生成虚构类型。'
    return
  }
  mailTypes.value = response.payload.data.nodes.map(node => ({ id: node.id, name: node.name }))
}
async function save(mutate: (draft: MailRuleBundle) => void): Promise<void> {
  const draft = plainClone(bundle.value)
  mutate(draft)
  draft.ownerId = isConfirmedOperator(props.userId) ? props.userId : owner.value
  const scope = scopeFromConnection(useWorkspace().connection.value)
  if (!scope || scope.operatorId !== props.userId) {
    message.value = '当前页面账号与已绑定会话不一致，未保存。'
    return
  }
  const response = await sendToBackground({ type: MessageType.Workspace, payload: { action: 'saveRules', bundle: draft, expectedScope: scope } }, 30_000)
  if (!response || response.type !== MessageType.WorkspaceResult || !response.payload.ok || !response.payload.rules) {
    if (response?.type === MessageType.WorkspaceResult && response.payload.rules) bundle.value = response.payload.rules
    message.value = response?.type === MessageType.WorkspaceResult ? response.payload.message : '保存失败，原配置未覆盖。'
    return
  }
  bundle.value = response.payload.rules
  subjectTemplate.value = bundle.value.subject.template
  bodyTemplate.value = bundle.value.body.template
  drafts.value = []
  message.value = response.payload.message || '已保存。'
}
function newId(prefix: string): string {
  return `${prefix}-${globalThis.crypto.randomUUID()}`
}
async function importRules(): Promise<void> {
  let parsed: MailRuleBundle
  try {
    parsed = JSON.parse(importText.value) as MailRuleBundle
  } catch {
    message.value = '导入失败，原配置未覆盖。'
    return
  }
  parsed.revision = bundle.value.revision
  parsed.ownerId = owner.value
  await save(draft => {
    draft.policies = parsed.policies
    draft.mappings = parsed.mappings
    draft.recipients = parsed.recipients
    draft.signatures = parsed.signatures
    draft.subject = parsed.subject
    draft.body = parsed.body
  })
  if (bundle.value.subject) message.value = message.value || '已导入当前账号的发文配置。'
}
function preview(): void {
  if (!bundle.value) return
  const files = props.files.map(file => ({ ...file, ...(file.customerBinding ? { customerBinding: { ...file.customerBinding } } : {}) }))
  const fingerprint = selectionFingerprint({ files, revision: bundle.value.revision, userId: owner.value, origin: accountOrigin.value })
  drafts.value = planDrafts({
    selectedAt: new Date().toISOString(),
    files,
    configVersion: bundle.value.revision,
    userId: owner.value,
    origin: accountOrigin.value,
    fingerprint
  }, bundle.value, customers.value, owner.value)
}

watch(() => [props.userId, accountOrigin.value], () => {
  drafts.value = []
  void reloadCustomers()
  void reloadRules()
}, { immediate: true })
watch(() => props.files, () => { drafts.value = [] }, { deep: true })
</script>

<template>
  <section class="card query-template" aria-label="发文规则">
    <strong>发文规则</strong>
    <p class="hint">配置归属：{{ scopeLabel }}。本地预览不是 EASY 邮件。选择或规则变化后需要重新生成，旧预览不能拿去创建。</p>
    <p v-if="message" class="hint">{{ message }}</p>
    <EmptyGuide v-if="customers.length === 0" text="还没有客户，发文方式没法配。去客户管理建一个再回来。" action="去创建客户" hash="/customers" />
    <label v-else>客户发文方式
      <ThemeSelect v-model="policyCustomer" placeholder="选择已有客户配置" :options="customers.map(item => ({ value: item.id, label: item.name }))" />
    </label>
    <label>方式
      <ThemeSelect v-model="policyMode" :options="[{ value: 'merge_by_customer_description', label: '同客户同文件描述合并' }, { value: 'single_file', label: '单个来文发文' }]" />
    </label>
    <button type="button" class="text-button" @click="save(draft => {
      if (!policyCustomer) return
      const current = draft.policies.find(item => item.customerProfileId === policyCustomer && item.sendMode === policyMode && !(item.remark ?? '').trim())
      const next = {
        customerProfileId: policyCustomer,
        sendMode: policyMode,
        ...(current?.remark ? { remark: current.remark } : {}),
        ...(current?.mailTypeId && current.mailTypeName ? { mailTypeId: current.mailTypeId, mailTypeName: current.mailTypeName } : {}),
        enabled: true,
        version: (current?.version ?? 0) + 1,
        updatedAt: new Date().toISOString()
      }
      draft.policies = draft.policies.filter(item => !(item.customerProfileId === policyCustomer && item.sendMode === policyMode && !(item.remark ?? '').trim())).concat(next)
    })">保存发文方式</button>

    <label>文件描述原文<input v-model="mapText" type="text" /></label>
    <label>发文类型
      <ThemeSelect v-model="mapTypeId" placeholder="选择发文类型" empty-text="发文类型还没读到。点开会重新读取。" :options="mailTypes.map(item => ({ value: item.id, label: item.name }))" @open="loadMailTypes" />
    </label>
    <button type="button" class="text-button" @click="save(draft => {
      const mailType = mailTypes.find(item => item.id === mapTypeId)
      if (!mapText.trim() || !mailType) return
      const result = upsertMapping(draft.mappings, { id: editingMapId || newId('map'), fileDescriptionText: mapText.trim(), mailTypeId: mailType.id, mailTypeName: mailType.name, enabled: true, version: 1, updatedAt: new Date().toISOString() })
      if (!result.ok) throw new Error(result.message)
      draft.mappings = result.mappings
      editingMapId = ''
    })">保存描述映射</button>
    <article v-for="item in bundle.mappings" :key="item.id" class="file-card">
      <p class="hint">{{ item.fileDescriptionId || item.fileDescriptionText }} → {{ item.mailTypeName }}（{{ item.enabled ? '启用' : '禁用' }}，版本 {{ item.version }}）</p>
      <button type="button" class="text-button" @click="editingMapId = item.id; mapText = item.fileDescriptionText ?? ''; mapTypeId = item.mailTypeId">编辑</button>
      <button type="button" class="text-button" @click="save(draft => {
        const current = draft.mappings.find(mapping => mapping.id === item.id)
        if (!current) return
        const result = upsertMapping(draft.mappings, { ...current, enabled: !current.enabled })
        if (!result.ok) throw new Error(result.message)
        draft.mappings = result.mappings
      })">{{ item.enabled ? '禁用' : '启用' }}</button>
      <button type="button" class="text-button" @click="save(draft => { draft.mappings = draft.mappings.filter(mapping => mapping.id !== item.id) })">删除本地映射</button>
    </article>

    <EmptyGuide v-if="customers.length === 0" text="还没有客户，收件人没法配。去客户管理建一个再回来。" action="去创建客户" hash="/customers" />
    <label v-else>收件人客户
      <ThemeSelect v-model="recipientCustomer" placeholder="选择客户" :options="customers.map(item => ({ value: item.id, label: item.name }))" />
    </label>
    <label>收件人<input v-model="recipientTo" type="text" placeholder="多个邮箱用逗号分隔" /></label>
    <label>抄送<input v-model="recipientCc" type="text" /></label>
    <button type="button" class="text-button" @click="save(draft => {
      if (!recipientCustomer) return
      draft.recipients = draft.recipients.filter(item => item.customerProfileId !== recipientCustomer)
      draft.recipients.push({ id: newId('to'), customerProfileId: recipientCustomer, name: '默认', to: recipientTo.split(/[,，]/), cc: recipientCc.split(/[,，]/), enabled: true, isDefault: true, version: 1, updatedAt: new Date().toISOString() })
    })">保存收件人</button>

    <label>签名名称<input v-model="signatureName" type="text" /></label>
    <label>签名内容<textarea v-model="signatureContent" rows="3" /></label>
    <button type="button" class="text-button" @click="save(draft => {
      const name = signatureName.trim()
      const content = signatureContent.trim()
      if (!name || !content) return
      draft.signatures.push({ id: newId('sign'), operatorId: owner, name: name.slice(0, 80), content: content.slice(0, 4000), enabled: true, isDefault: false, version: 1, updatedAt: new Date().toISOString() })
    })">添加暂存签名</button>

    <label>标题模板<input v-model="subjectTemplate" type="text" /></label>
    <p class="hint">原站默认：{贵方案号}-{我方文号}-{案件名称}{发文类型}。没有内容的段会去掉。固定文字直接写。</p>
    <label class="check-line"><input v-model="countInjection" type="checkbox" />多个文件时在“关于”后注入数量</label>
    <label>没有“关于”时
      <ThemeSelect v-model="missingAnchor" :options="[{ value: 'keep', label: '保留原标题' }, { value: 'prefix', label: '添加前缀' }, { value: 'confirm', label: '标记人工确认' }]" />
    </label>
    <label>正文<textarea v-model="bodyTemplate" rows="3" /></label>
    <label>补充文本<textarea v-model="bodySupplement" rows="2" /></label>
    <button type="button" class="text-button" @click="save(draft => {
      draft.subject = { template: subjectTemplate, countInjection, anchor: '关于', missingAnchor, version: draft.subject.version + 1 }
      draft.body = { template: bodyTemplate, supplement: bodySupplement, version: draft.body.version + 1 }
    })">保存标题和正文</button>
    <button type="button" class="text-button" @click="importText = repository?.exportJson(bundle) ?? ''">导出配置</button>
    <label>导入配置<textarea v-model="importText" rows="3" /></label>
    <button type="button" class="text-button" @click="importRules">导入配置</button>
    <button type="button" class="search-submit" :disabled="files.length === 0" @click="preview">重新生成预览</button>
    <AutomationPanel :bridge="bridge" :user-id="userId" :business-origin="accountOrigin" :files="files" :rules="bundle" :profiles="customers" :query-template-version="queryTemplateVersion" />
    <LiveAcceptancePanel :bridge="bridge" :user-id="userId" :business-origin="accountOrigin" />
    <ControlledExecutionPanel :bridge="bridge" :user-id="userId" :business-origin="accountOrigin" :files="files" :rules="bundle" :profiles="customers" :query-template-version="queryTemplateVersion" />
    <article v-for="draft in drafts" :key="draft.id" class="file-card">
      <strong>{{ draft.status === 'ready' ? '可核对' : draft.status === 'warning' ? '需确认' : '不能发文' }} · {{ draft.sendMode === 'single_file' ? '单个来文' : '同描述合并' }}</strong>
      <p class="hint">客户配置 {{ draft.customerProfileId || '未绑定' }} · {{ draft.files.length }} 个文件 · {{ draft.mailTypeName || '未映射发文类型' }}</p>
      <p class="hint">收件人 {{ draft.to.join('、') || '空' }} · 抄送 {{ draft.cc.join('、') || '空' }}</p>
      <p>{{ draft.subject || '无主题' }}</p>
      <pre class="hint">{{ draft.body }}</pre>
      <p v-if="draft.signature" class="hint">签名：{{ draft.signature }}</p>
      <p class="hint">规则来源 {{ JSON.stringify(draft.ruleVersions) }}</p>
      <p v-for="issue in draft.issues" :key="issue.code + issue.field" class="hint">{{ issue.message }}</p>
      <MailExecutionPanel :bridge="bridge" :draft="draft" :files="files" :revision="bundle.revision" @changed="mailStates[draft.id] = { mailId: $event?.record.mailId ?? '', state: $event?.record.state ?? '' }" />
      <WorkflowPanel :bridge="bridge" :mail-id="mailStates[draft.id]?.mailId ?? ''" :ready="mailStates[draft.id]?.state === 'COMPLETED'" />
    </article>
  </section>
</template>
