import { describe, expect, it } from 'vitest'
import { filterSelectOptions, highlightAfterKey, menuWidthForLabels, placeMenu, selectNeedsSearch, showsGroup, textOptions, treeMenuWidth } from '../../src/components/theme-select'

describe('theme select', () => {
  it('opens downward and flips upward when the lower space is tight', () => {
    const down = placeMenu({ top: 100, bottom: 136, left: 20, width: 220 }, { width: 800, height: 600 })
    expect(down.edge).toBe('top')
    expect(down.top).toBe(142)
    expect(down.left).toBe(20)
    expect(down.width).toBe(220)
    const up = placeMenu({ top: 540, bottom: 576, left: 20, width: 220 }, { width: 800, height: 600 })
    expect(up.edge).toBe('bottom')
    expect(up.bottom).toBeLessThan(80)
    expect(up.maxHeight).toBeGreaterThan(80)
  })

  it('keeps the menu inside the viewport', () => {
    const placed = placeMenu({ top: 40, bottom: 76, left: 760, width: 220 }, { width: 800, height: 600 })
    expect(placed.left + placed.width).toBeLessThanOrEqual(792)
  })

  it('widens the menu to the longest option and still stays inside the viewport', () => {
    const wide = placeMenu({ top: 100, bottom: 136, left: 20, width: 180 }, { width: 800, height: 600 }, 240, 420)
    expect(wide.width).toBe(420)
    expect(wide.left).toBe(20)
    const shifted = placeMenu({ top: 40, bottom: 76, left: 500, width: 180 }, { width: 800, height: 600 }, 240, 420)
    expect(shifted.width).toBe(420)
    expect(shifted.left + shifted.width).toBeLessThanOrEqual(792)
    const labels = menuWidthForLabels(['短', 'tclip@centips.com<tclip@centips.com>'])
    expect(labels).toBeGreaterThan(menuWidthForLabels(['短']))
    const tree = treeMenuWidth([
      { value: 'a', label: '父级' },
      { value: 'b', label: '很长的子级名称', parent: 'a' }
    ])
    expect(tree).toBeGreaterThan(menuWidthForLabels(['很长的子级名称']))
  })

  it('moves the highlight only after the menu is open', () => {
    expect(highlightAfterKey(-1, 3, 'ArrowDown', false).action).toBe('open')
    expect(highlightAfterKey(-1, 3, 'ArrowDown', true)).toEqual({ highlight: 0, action: 'move' })
    expect(highlightAfterKey(2, 3, 'ArrowDown', true).highlight).toBe(0)
    expect(highlightAfterKey(0, 3, 'Enter', true)).toEqual({ highlight: 0, action: 'select' })
    expect(highlightAfterKey(1, 3, 'Escape', true).action).toBe('close')
  })

  it('searches only when there are more than ten options', () => {
    const options = textOptions(['不限', '中国', '美国', '日本', '德国', '法国', '英国', '韩国', '印度', '巴西'])
    expect(selectNeedsSearch(options.length)).toBe(false)
    expect(selectNeedsSearch(options.length + 1)).toBe(true)
    const longer = textOptions([...options.map(item => item.label), '欧洲专利局'])
    expect(filterSelectOptions(longer, ' 美 ')).toEqual([{ value: '美国', label: '美国' }])
    expect(filterSelectOptions(longer, '')).toHaveLength(11)
  })

  it('shows a group heading when the group changes', () => {
    const options = textOptions(['手动查询']).concat([
      { value: 'a', label: '甲', group: 'EASY' },
      { value: 'b', label: '乙', group: 'EASY' },
      { value: 'c', label: '丙', group: '本地' }
    ])
    expect(showsGroup(options, 0)).toBe(false)
    expect(showsGroup(options, 1)).toBe(true)
    expect(showsGroup(options, 2)).toBe(false)
    expect(showsGroup(options, 3)).toBe(true)
  })
})